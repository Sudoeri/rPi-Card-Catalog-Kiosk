#Create monitoroff.sh first in the terminal with : sudo nano /home/pi/monitoroff.sh and then insert the following

#!/bin/bash
tvservice -o
